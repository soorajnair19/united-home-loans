package com.lti.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.lti.model.Customer;
import com.lti.service.ICustomerService;

import oracle.jdbc.util.Login;

@Controller
public class CustomerController {

	
	private ICustomerService customerService;
	
	@Autowired
	public void setCustomerService(ICustomerService cs) {
		this.customerService = cs;
	}
	
	
	@RequestMapping(value="/register")
	public String goRegister(Model model) {
	model.addAttribute("customer",new Customer());
		return "register";
	}
	

	@RequestMapping("/login")
	public String showLoginView(Model model)
	{
		model.addAttribute("customer", new Customer());
		return "login";
	}
	
	
	
	
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addCustomer(
			@ModelAttribute("customer") 
			@Valid Customer customer, 
			BindingResult result, 
			Model model) {
		if (result.hasErrors()) {
				return "register";
			} 

		this.customerService.addCustomer(customer);
		return "login";
		}
	
	@RequestMapping(value="/entry",method=RequestMethod.POST)
	public String LoginValidation(Model model,HttpServletRequest req)
	{	
		String emailId=req.getParameter("emailId");
		String password=req.getParameter("password");
		
		if(customerService.verifyUser(emailId, password))
		{

			System.out.println("Login success");
		return "customerprofile";
		
		}
		return "login";
	}
	
	@RequestMapping(value="/aboutus")
	public String aboutus(Model model) {
	model.addAttribute("customer",new Customer());
		return "aboutus";
	} 
	
	@RequestMapping(value="/faq")
	public String faq(Model model) {
	model.addAttribute("customer",new Customer());
		return "faq";
	} 
	
	
	
	
		
	
}