package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.IAdminDao;
import com.lti.model.Customer;



@Service
@Transactional
public class AdminServiceImpl implements IAdminService{
	
	@Autowired
	private IAdminDao iAdminDao;


	public void setiAdminDao(IAdminDao iAdminDao) {
		this.iAdminDao = iAdminDao;
	}

	@Override
	public List<Customer> custlist() {
		
		return this.iAdminDao.custlist();
	}

	@Override
	public void acceptCust(String emailId) {
		
	}

	@Override
	public void rejectCust(String emailId) {
		
		
	}
	

}
