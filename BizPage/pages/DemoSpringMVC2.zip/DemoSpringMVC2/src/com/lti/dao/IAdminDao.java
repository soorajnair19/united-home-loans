package com.lti.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.model.Customer;



@Repository
public interface IAdminDao {
	
	public List<Customer> custlist();
	
	public void acceptCust(String emailId);
	
	public void rejectCust(String emailId);
	
}
