package com.lti.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CustomerDetails")
public class CustomerDetails {

	@Id
	@GeneratedValue(generator = "customerdet_sequence", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "customerdet_sequence", sequenceName = "customerdet_sequence")
	@Column
	private int detailsId;
	
	@Column(name="balance")
	private double accountBalance;
	
	/*@Column(name="type")
	private String typeOfEmp;
	
	
	//customer getters setters y/n?
	
	@Column(name="age")
	private int retirementAge;*/
	
/*	@Column(name="orgtype")
	private String organizationType;
	
	@Column(name="company")
	private String employerName;*/
	
	@Column(name="salary")
	private double salary;
	
	@Column(name="tenure")
	private int tenure;
	
	@Column(name="loanamt")
	private double loanAmount;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private Customer customer;
	

	

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	/*public String getTypeOfEmp() {
		return typeOfEmp;
	}

	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}

	public int getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(int retirementAge) {
		this.retirementAge = retirementAge;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}*/

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	@Override
	public String toString() {
		return "CustomerDetails [detailsId=" + detailsId + ", accountBalance=" + accountBalance + ", salary=" + salary
				+ ", tenure=" + tenure + ", loanAmount=" + loanAmount + ", customer=" + customer + "]";
	}

	public int getDetailsId() {
		return detailsId;
	}

	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}

	public CustomerDetails() {
		super();
	}

	
	
	
	
	
	
	
	
	
}
