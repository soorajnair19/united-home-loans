package com.lti.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.lti.model.Customer;
import com.lti.service.ICustomerService;

import oracle.jdbc.util.Login;

@Controller
public class CustomerController {

	
	

private ICustomerService customerService;

@Autowired
public void setCustomerService(ICustomerService cs) {
this.customerService = cs;
}


@RequestMapping(value="/register")
public String goRegister(Model model) {
model.addAttribute("customer",new Customer());
return "register";
}


@RequestMapping("/login")
public String showLoginView(Model model)
{
model.addAttribute("customer", new Customer());
return "login";
}





@RequestMapping(value = "/add", method = RequestMethod.POST)
public String addCustomer(
@ModelAttribute("customer") 
@Valid Customer customer, 
BindingResult result, 
Model model) {
if (result.hasErrors()) {
return "register";
} 

this.customerService.addCustomer(customer);
return "login";
}

@RequestMapping(value = "/entry", method = RequestMethod.POST)
public String LoginValidation(@ModelAttribute ("customer")
								@Valid Customer u, 
								BindingResult result, HttpServletRequest req, HttpSession session,Model model) {
	String emailId = req.getParameter("emailId");
	String password = req.getParameter("password");

 

	if (emailId.equals("admin@gmail.com") && password.equals("admin"))

	{
		return "adminprofile";

	} else if (customerService.verifyUser(emailId, password)) {
		
		/*session.setAttribute("emailId",u.getEmailId());
		return "redirect:/customerprofile";*/
		
		Customer customer = customerService.getCustomer(emailId, password);
		
		session.setAttribute("customer", customer);
		session.setAttribute("country", customer.getCountry());
		session.getAttribute("country");
		
		
		session.setAttribute("firstName", customer.getCustomerFirstName());
		session.setAttribute("middleName", customer.getCustomerMiddleName());
		session.setAttribute("lastName", customer.getCustomerLastName());
		session.setAttribute("emailId", customer.getEmailId());
		session.setAttribute("gender", customer.getGender());
		session.setAttribute("mobile", customer.getMobileNo());
		session.setAttribute("pan", customer.getPanNo());
		session.setAttribute("aadhar", customer.getAadharNo());

		
		
		
		
		//session.setAttribute("balance", customer.getAcoountDetails().getBalance()); //check for this
		
		
		
		
		
		
		session.getAttribute("customer");
		
		session.setAttribute("first", customer.getCustomerFirstName());
		System.out.println(session.getAttribute("first"));
	System.out.println("Login success");
	return "customerprofile";

	} else
		return "login";

}



/*@RequestMapping(value="/entry",method=RequestMethod.POST)
public String LoginValidation(Model model,HttpServletRequest req, HttpSession session)
{  
String emailId=req.getParameter("emailId");
String password=req.getParameter("password");
System.out.println("inside login");


if(customerService.verifyUser(emailId, password))
{
			
	if(emailId=="pnp@gmail.cmo"&&password=="pnp,pnp")
	{
		System.out.println("inside pnp");
		return "adminprofile";
		
	}
	
	
	//session.setAttribute("emailId", emailId);
	Customer customer = customerService.getCustomer(emailId, password);
	
	session.setAttribute("customer", customer);
	session.setAttribute("country", customer.getCountry());
	session.getAttribute("country");
	
	
	session.setAttribute("firstName", customer.getCustomerFirstName());
	session.setAttribute("middleName", customer.getCustomerMiddleName());
	session.setAttribute("lastName", customer.getCustomerLastName());
	session.setAttribute("emailId", customer.getEmailId());
	session.setAttribute("gender", customer.getGender());
	session.setAttribute("mobile", customer.getMobileNo());
	session.setAttribute("pan", customer.getPanNo());
	session.setAttribute("aadhar", customer.getAadharNo());

	
	
	
	
	//session.setAttribute("balance", customer.getAcoountDetails().getBalance()); //check for this
	
	
	
	
	
	
	session.getAttribute("customer");
	
	session.setAttribute("first", customer.getCustomerFirstName());
	System.out.println(session.getAttribute("first"));
System.out.println("Login success");
return "customerprofile";

}
return "login";
}*/

@RequestMapping(value="/logout", method=RequestMethod.GET)
public String logout(HttpSession session) {
session.invalidate();
System.out.println("session successfully invalidated");
return "redirect:";
} 


@RequestMapping(value="/aboutus")
public String aboutus(Model model) {
model.addAttribute("customer",new Customer());
return "aboutus";
} 

@RequestMapping(value="/aboutus1")
public String aboutus1(Model model) {
model.addAttribute("customer",new Customer());
return "aboutus1";
} 


@RequestMapping(value="/faq")
public String faq(Model model) {
model.addAttribute("customer",new Customer());
return "faq";
} 

@RequestMapping(value="/faq1")
public String faq1(Model model) {
model.addAttribute("customer",new Customer());
return "faq1";
} 

@RequestMapping(value="/apply")
public String apply(Model model) {
model.addAttribute("customer",new Customer());
return "apply";
} 

@RequestMapping(value="/accountdetails")
public String accountdetails(Model model) {
model.addAttribute("customer",new Customer());
return "accountdetails";
} 


@RequestMapping(value="/approveddetails")
public String approveddetails(Model model) {
model.addAttribute("customer",new Customer());
return "approveddetails";
} 


@RequestMapping(value="/adminprofile")
public String adminprofile(Model model) {
model.addAttribute("customer",new Customer());
return "adminprofile";
} 


@RequestMapping(value="/bankdocs")
public String bankdocs(Model model) {
model.addAttribute("customer",new Customer());
return "bankdocs";
} 

@RequestMapping(value="/calculators")
public String calculators(Model model) {
model.addAttribute("customer",new Customer());
return "calculators";
} 

@RequestMapping(value="/calculators1")
public String calculators1(Model model) {
model.addAttribute("customer",new Customer());
return "calculators1";
} 


@RequestMapping(value="/customerprofile")
public String customerprofile(Model model) {
model.addAttribute("customer",new Customer());
return "customerprofile";
} 


@RequestMapping(value="/eligibilitycalculator")
public String eligibilitycalculator(Model model) {
model.addAttribute("customer",new Customer());
return "eligibilitycalculator";
} 

@RequestMapping(value="/eligibilitycalculator1")
public String eligibilitycalculator1(Model model) {
model.addAttribute("customer",new Customer());
return "eligibilitycalculator1";
} 

@RequestMapping(value="/emicalculator")
public String emicalculator(Model model) {
model.addAttribute("customer",new Customer());
return "emicalculator";
} 


@RequestMapping(value="/emicalculator1")
public String emicalculator1(Model model) {
model.addAttribute("customer",new Customer());
return "emicalculator1";
} 



@RequestMapping(value="/forgetpassword")
public String forgetpassword(Model model) {
model.addAttribute("customer",new Customer());
return "forgetpassword";
} 



@RequestMapping(value="/incomedetails")
public String incomedetails(Model model) {
model.addAttribute("customer",new Customer());
return "incomedetails";
} 


@RequestMapping(value="/loandetails")
public String loandetails(Model model) {
model.addAttribute("customer",new Customer());
return "loandetails";
} 


@RequestMapping(value="/loandocs")
public String loandocs(Model model) {
model.addAttribute("customer",new Customer());
return "loandocs";
} 
@RequestMapping(value="/loantracker")
public String loantracker(Model model) {
model.addAttribute("customer",new Customer());
return "loantracker";
} 


@RequestMapping(value="/rejecteddetails")
public String rejecteddetails(Model model) {
model.addAttribute("customer",new Customer());
return "rejecteddetails";
} 


@RequestMapping(value="/mydocuments")
public String mydocuments(Model model) {
model.addAttribute("customer",new Customer());
return "mydocuments";
} 


@RequestMapping(value="/")
public String index(Model model) {
model.addAttribute("customer",new Customer());
return "index";
} 

@RequestMapping(value="/index1")
public String index1(Model model) {
model.addAttribute("customer",new Customer());
return "index1";
} 


@RequestMapping(value="/resetpassword")
public String resetpassword(Model model) {
model.addAttribute("customer",new Customer());
return "resetpassword";
} 


@RequestMapping(value="/userdetails")
public String userdetails(Model model,HttpSession session, HttpServletRequest req) {

	String emailId=req.getParameter("emailId");
	String password=req.getParameter("password");
	
	
	
	//Customer customer = customerService.getCustomer(emailId, password);
	
	/*session.setAttribute("first", customer.getCustomerFirstName());
	session.getAttribute("first");*/
	System.out.println("inside details");
	System.out.println(session.getAttribute("emailId"));
model.addAttribute("customer",new Customer());
return "userdetails";

} 


@RequestMapping(value="/error")
public String errorer(Model model) {
model.addAttribute("customer",new Customer());
return "error";
} 

}