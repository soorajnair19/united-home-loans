package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Customer;

@Service
public interface ICustomerDetailsService {
	
	
	public List<Customer> custlist1();

}
