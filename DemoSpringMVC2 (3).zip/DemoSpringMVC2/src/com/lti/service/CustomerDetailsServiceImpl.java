package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.ICustomerDetailsDao;
import com.lti.model.Customer;



@Service
@Transactional
public class CustomerDetailsServiceImpl implements ICustomerDetailsService{

	
	@Autowired
	private ICustomerDetailsDao iCustomerDetailsDao;



	@Override
	public List<Customer> custlist1() {
		
		System.out.println("customerdetaildaoimpl");
		return this. iCustomerDetailsDao.custlist1();
		}
	}
	
	
	


