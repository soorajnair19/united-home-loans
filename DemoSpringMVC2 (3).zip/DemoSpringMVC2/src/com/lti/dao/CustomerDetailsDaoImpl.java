package com.lti.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Customer;

@Transactional
@Repository
public class CustomerDetailsDaoImpl implements ICustomerDetailsDao {
	
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Customer> custlist1() {
		
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String query="from Customer";
		Query q=session.createQuery(query);
		List<Customer> custlist1=q.list();
		System.out.println(custlist1);
		System.out.println("bye");
		tx.commit();
		session.close();
		return custlist1;

		
	}
	
	
	

}
