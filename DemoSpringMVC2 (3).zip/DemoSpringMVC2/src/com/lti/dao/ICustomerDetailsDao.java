package com.lti.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.model.Customer;



@Repository
public interface ICustomerDetailsDao {
	
	
	public List<Customer> custlist1();

}
